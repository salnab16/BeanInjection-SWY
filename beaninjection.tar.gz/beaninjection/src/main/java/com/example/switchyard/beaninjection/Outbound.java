package com.example.switchyard.beaninjection;

public interface Outbound {
	public String outReference(String message);
}
