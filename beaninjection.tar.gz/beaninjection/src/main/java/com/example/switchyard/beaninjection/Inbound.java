package com.example.switchyard.beaninjection;

public interface Inbound {

	public void message(String s);
}
