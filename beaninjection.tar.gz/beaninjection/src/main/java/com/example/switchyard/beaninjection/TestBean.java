package com.example.switchyard.beaninjection;

import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named("TestBean")
public class TestBean {

	private static final Logger LOG = LoggerFactory.getLogger(Route.class);
	
	
	public String getMessage()
	{
		LOG.info("Read Message from TestBean");
		return "Reading Message from TestBean";
	}
	
}
