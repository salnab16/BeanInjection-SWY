package com.example.switchyard.beaninjection;

import javax.inject.Inject;

import org.apache.camel.BeanInject;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Route extends RouteBuilder {

	private static final Logger LOG = LoggerFactory.getLogger(Route.class);
	
	@Inject
	TestBean b;
	public void configure() {
		
		LOG.info("Before");
		// Trying to call a method of the injected bean
		// LOG.info(b.getMessage());
		LOG.info("After");
		from("switchyard://Inbound")
		.process(new Processor(){

			@Override
			public void process(Exchange arg0) throws Exception {
				LOG.info(b.getMessage());
				LOG.info("After...");
			}
			
		})
			.log("Received message for 'Inbound' : ${body}")
			.beanRef("TestBean", "getMessage()");
	}
}
